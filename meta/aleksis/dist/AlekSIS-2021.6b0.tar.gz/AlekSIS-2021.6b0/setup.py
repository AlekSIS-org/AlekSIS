# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['aleksis_meta']

package_data = \
{'': ['*']}

install_requires = \
['aleksis-app-alsijil==2.0b0',
 'aleksis-app-chronos==2.0b0',
 'aleksis-app-csvimport==2.0b0',
 'aleksis-app-dashboardfeeds==2.0b0',
 'aleksis-app-hjelp==2.0b0',
 'aleksis-app-ldap==2.0b0',
 'aleksis-app-untis==2.0b0']

setup_kwargs = {
    'name': 'aleksis',
    'version': '2021.6b0',
    'description': 'Free School Information System Distribution',
    'long_description': 'AlekSIS - The Free School Information System\n============================================\n\nAlekSIS is a web-based school information system (SIS) which can be used to\nmanage and/or publish organisational subjects of educational institutions.\n\nThe bundled applications provide a rich set of functionality for a wide range\nof aspects in schools, like managing students and teachers, timetables and\nsubstitutions, class registers, personal notes, homework and assignments,\nand a lot more. Apps are being added regularly to extend the feature set of\nAlekSIS.\n\nUnder the hood, AlekSIS is a complete framework for app development, allowing\neveryone to add their own functionality, for example for processes specific to\ntheir own school. While being a professional product for schools, AlekSIS also\naims at being easy to learn and to be usable in education itself, by providing\nthe tools needed to create apps together with students.\n\nAlekSIS is the perfect fit for schools that are looking for a robust and\nfeature-rich foundation for their information management needs, a tool for\nmaximisng transparency towards parents, students and staff, and also want to\nensure easy customisation to make the software fulfill their needs.\n\nLicence\n-------\n\n::\n\n  Copyright © 2017-2021 The AlekSIS Team <aleksis-dev@lists.teckids.org>\n\n  Licenced under the EUPL, version 1.2 or later, by Teckids e.V. (Bonn, Germany).\n\nPlease see the LICENCE.rst file accompanying this distribution for the\nfull licence text or on the `European Union Public Licence`_ website\nhttps://joinup.ec.europa.eu/collection/eupl/guidelines-users-and-developers\n(including all other official language versions).\n\nPlease consult the separate apps for specific copyright information.\n\n.. _AlekSIS: https://aleksis.org\n.. _European Union Public Licence: https://eupl.eu/\n.. _EduGit: https://edugit.org/AlekSIS/official/AlekSIS\n',
    'author': 'Dominik George',
    'author_email': 'dominik.george@teckids.org',
    'maintainer': 'Jonathan Weth',
    'maintainer_email': 'wethjo@katharineum.de',
    'url': 'https://aleksis.org/',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
}


setup(**setup_kwargs)
