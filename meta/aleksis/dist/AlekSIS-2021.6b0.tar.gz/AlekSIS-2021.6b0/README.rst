AlekSIS - The Free School Information System
============================================

AlekSIS is a web-based school information system (SIS) which can be used to
manage and/or publish organisational subjects of educational institutions.

The bundled applications provide a rich set of functionality for a wide range
of aspects in schools, like managing students and teachers, timetables and
substitutions, class registers, personal notes, homework and assignments,
and a lot more. Apps are being added regularly to extend the feature set of
AlekSIS.

Under the hood, AlekSIS is a complete framework for app development, allowing
everyone to add their own functionality, for example for processes specific to
their own school. While being a professional product for schools, AlekSIS also
aims at being easy to learn and to be usable in education itself, by providing
the tools needed to create apps together with students.

AlekSIS is the perfect fit for schools that are looking for a robust and
feature-rich foundation for their information management needs, a tool for
maximisng transparency towards parents, students and staff, and also want to
ensure easy customisation to make the software fulfill their needs.

Licence
-------

::

  Copyright © 2017-2021 The AlekSIS Team <aleksis-dev@lists.teckids.org>

  Licenced under the EUPL, version 1.2 or later, by Teckids e.V. (Bonn, Germany).

Please see the LICENCE.rst file accompanying this distribution for the
full licence text or on the `European Union Public Licence`_ website
https://joinup.ec.europa.eu/collection/eupl/guidelines-users-and-developers
(including all other official language versions).

Please consult the separate apps for specific copyright information.

.. _AlekSIS: https://aleksis.org
.. _European Union Public Licence: https://eupl.eu/
.. _EduGit: https://edugit.org/AlekSIS/official/AlekSIS
